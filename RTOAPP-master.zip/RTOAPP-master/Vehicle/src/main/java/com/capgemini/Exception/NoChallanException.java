package com.capgemini.Exception;

public class NoChallanException extends Exception {

	public NoChallanException(String string) {
		super(string);
	}

}

package com.capgemini.Exception;

public class NoChallanPaymentException extends Exception {

	public NoChallanPaymentException(String string) {
		super(string);
	}

}

package com.capgemini.dao;

import java.text.ParseException;
import java.util.List;

import com.capgemini.Exception.NoChallanException;
import com.capgemini.Exception.NoChallanPaymentException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Documents;

public interface LicenseDao {
	public String createLLRequest(Application llApplication);
	public String createDLRequest(Application dlApplication);
	public String saveDocuments(Documents documents);
	public String checkChallanByVehicleNumber(String vehicleNumber) throws NoChallanException;
	public String payChallanByVehicleNumber(String vehicleNumber) throws NoChallanPaymentException;
    public String payFees(int amount);
	public String emailFeesReceipt(String email);
	public String updateSlotLLTest(Appointment appointment);
	public String updateSlotDLTest(Appointment appointment);
	public List<Appointment> readAvailableSlots() throws ParseException;
	public String updateLL(Appointment llAppointment);
	public String updateDL(Appointment dlAppointment);
	public String cancelAppointment(Appointment appointment);
}

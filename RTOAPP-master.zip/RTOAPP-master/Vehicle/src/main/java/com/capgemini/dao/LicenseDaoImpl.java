package com.capgemini.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.capgemini.Exception.NoChallanException;
import com.capgemini.Exception.NoChallanPaymentException;
import com.capgemini.model.Applicant;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Challan;
import com.capgemini.model.Documents;

public class LicenseDaoImpl implements LicenseDao {

	private EntityManager em;

	public LicenseDaoImpl() {
		em = JPAUtil.getEntityManager();
	}

	@Override
	public String createLLRequest(Application llApplication) {
		em.getTransaction().begin();
		em.persist(llApplication);
		em.getTransaction().commit();

		return "Application for LL Request created";
	}

	@Override
	public String createDLRequest(Application dlApplication) {
		em.getTransaction().begin();
		em.persist(dlApplication);
		em.getTransaction().commit();

		return "Application for DL request created";
	}

	@Override
	public String saveDocuments(Documents documents) {

		em.getTransaction().begin();
		em.persist(documents);
		em.getTransaction().commit();
		return "Documents are uploaded";
	}

	@Override
	public String payFees(int amount) {
		em.getTransaction().begin();
		Applicant a = new Applicant();
		a = em.find(Applicant.class, amount);
		em.getTransaction().commit();
		return "Fees paid";

	}

	// mine starts from here :)
	@Override
	public String updateSlotLLTest(Appointment appointment) {
		em.getTransaction().begin();
		Query query = em.createQuery("UPDATE Appointment SET test_slot = :p");
		query.setParameter("p", appointment.getTimeSlot()).executeUpdate();
		em.getTransaction().commit();

		return "LL Slot updated";
	}

	@Override
	public String updateSlotDLTest(Appointment appointment) {
		em.getTransaction().begin();
		Query query = em.createQuery("UPDATE Appointment SET test_slot = :p");
		query.setParameter("p", appointment.getTimeSlot()).executeUpdate();
		em.getTransaction().commit();
		return "DL Slot updated";
	}

	@Override
	public List<Appointment> readAvailableSlots() throws ParseException {
		Appointment app = new Appointment();
		List<Appointment> list = new ArrayList<>();
		DateTimeFormatter forma = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		String firstDate = forma.format(LocalDate.now()).toString();
		String firstTime = "09:00 AM";
		String secondDate = forma.format(LocalDate.now()).toString();
		String secondTime = "05:00 PM";

		String format = "dd/MM/yyyy hh:mm a";

		SimpleDateFormat sdf = new SimpleDateFormat(format);

		Date dateObj1 = sdf.parse(firstDate + " " + firstTime);
		Date dateObj2 = sdf.parse(secondDate + " " + secondTime);

		long dif = dateObj1.getTime();
		while (dif < dateObj2.getTime()) {
			Date slot = new Date(dif);
			app.setTimeSlot(slot.toString());
			list.add(app);
			dif += 7200000;
		}
		return list;
	}

	@Override
	public String updateLL(Appointment llAppointment) {

		em.getTransaction().begin();
		em.merge(llAppointment);
		em.getTransaction().commit();

		return "Appointment created and waiting for RTO Officer's approval";
	}

	@Override
	public String updateDL(Appointment dlAppointment) {

		em.getTransaction().begin();
		em.merge(dlAppointment);
		em.getTransaction().commit();

		return "Appointment created and waiting for RTO Officer's approval";
	}

	@Override
	public String cancelAppointment(Appointment appointment) {

		em.getTransaction().begin();

		Query query = em.createQuery("delete from Appointment where appointmentnumber = :p");
		query.setParameter("p", appointment.getAppointmentNumber()).executeUpdate();

		em.getTransaction().commit();

		return "Appointment cancelled";
	}

	@Override
	public String checkChallanByVehicleNumber(String vehicleNumber) throws NoChallanException {
		em.getTransaction().begin();
		Challan ch = new Challan();
		ch = em.find(Challan.class, ch);
		String str = " ";
		if (ch.getVehicleNumber().equals(ch)) {
			str = "Challan Exists";
		} else {
			throw new NoChallanException("Challan doesn't exists");

		}

		em.getTransaction().commit();
		return str;
	}

	@Override
	public String payChallanByVehicleNumber(String vehicleNumber) throws NoChallanPaymentException {
		em.getTransaction().begin();
		Challan ch = new Challan();
		ch = em.find(Challan.class, ch);
		String str = " ";
		if (ch.getVehicleNumber().equals(ch)) {

			str = "Challan Payment Exists and amount";
		} else {
			throw new NoChallanPaymentException("Challan Payment doesn't Exists");
		}
		em.getTransaction().commit();
		return str;
	}

	@Override
	public String emailFeesReceipt(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}

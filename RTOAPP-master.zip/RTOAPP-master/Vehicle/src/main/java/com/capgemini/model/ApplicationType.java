package com.capgemini.model;

public enum ApplicationType {
	LL, DL
}

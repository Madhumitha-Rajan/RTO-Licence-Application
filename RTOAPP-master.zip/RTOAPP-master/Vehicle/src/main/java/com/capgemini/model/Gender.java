package com.capgemini.model;
public enum Gender{
	MALE, FEMALE, OTHER
}
package com.capgemini.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * List of RTO offices in Maharashtra
 */
@Entity
@Table(name = "RTOOffice")
public class RTOOffice {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "rto_id")
    private int rtoId;
	@Column(name = "rto_name")
	private String rtoName;
	
	
	
	public int getRtoId() {
		return rtoId;
	}
	public void setRtoId(int rtoId) {
		this.rtoId = rtoId;
	}
	public String getRtoName() {
		return rtoName;
	}
	public void setRtoName(String rtoName) {
		this.rtoName = rtoName;
	}
	
	
	
}

package com.capgemini.service;

import java.text.ParseException;
import java.util.List;

import com.capgemini.Exception.NoChallanException;
import com.capgemini.Exception.NoChallanPaymentException;
import com.capgemini.dao.LicenseDao;
import com.capgemini.dao.LicenseDaoImpl;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Documents;

public class LicenseServiceImpl implements LicenseService {

	private LicenseDao dao;

	public LicenseServiceImpl() {
		dao = new LicenseDaoImpl();
	}

	@Override
	public String applyForLL(Application llApplication) {
		String result = dao.createLLRequest(llApplication);
		return result;
	}

	@Override
	public String applyForDL(Application dlApplication) {
		String result = dao.createDLRequest(dlApplication);
		return result;
	}

	@Override
	public String uploadDocuments(Documents documents) {
		String result = dao.saveDocuments(documents);
		return result;
	}

	@Override
	public String checkChallanByVehicleNumber(String vehicleNumber) {
		String result=" ";
		try {
			result = dao.checkChallanByVehicleNumber(vehicleNumber);
		} catch (NoChallanException e) {
			
			result =e.getMessage();
		}
		return result;
	}

	@Override
	public String payChallanByVehicleNumber(String vehicleNumber) {
		String result=" ";
		try {
			result = dao.payChallanByVehicleNumber(vehicleNumber);
		} catch (NoChallanPaymentException e) {
			result = e.getMessage();
		}
		return result;
	
	}

	@Override
	public String payFees(int amount) {
		String result = dao.payFees(amount);
		return result;
	}

	@Override
	public String emailFeesReceipt(String email) {
		// will email the fee receipt to the email passed as argument
		// will return successfully sent receipt to your mail
        String result = dao.emailFeesReceipt(email);
		return result;
	}

	@Override
	public String bookSlotLLTest(Appointment appointment) {

		String result = dao.updateDL(appointment);

		return result;
	}

	@Override
	public String bookSlotDLTest(Appointment appointment) {

		String result = dao.updateLL(appointment);
		return result;
	}

	@Override
	public List<Appointment> getAvailableSlots() {
		List<Appointment> app = null;
		try {
			app = dao.readAvailableSlots();
		} catch (ParseException e) {
			System.out.println("Exception occured");
		}
		return app;
	}

	@Override
	public String renewLL(Application llApplication) {
		String result = dao.updateLL(llApplication.getAppointment());
		return result;
	}

	@Override
	public String renewDL(Application dlApplication) {
		String result = dao.updateDL(dlApplication.getAppointment());
		return result;
	}

	@Override
	public String cancelAppointment(Appointment appointment) {
		String result = dao.cancelAppointment(appointment);
		return result;
	}

}

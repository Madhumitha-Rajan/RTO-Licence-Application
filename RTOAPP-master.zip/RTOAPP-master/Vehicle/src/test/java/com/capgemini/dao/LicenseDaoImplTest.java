package com.capgemini.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.capgemini.model.Appointment;
import com.capgemini.model.Documents;

class LicenseDaoImplTest {

	LicenseDaoImpl ldi = new LicenseDaoImpl();
	@Test
	public void documentsTest() {
        Documents doc = new Documents();
        doc.setIdProof("IDProf2");
        doc.setAddressProof("AddrresP1");
        doc.setPhoto("Phot12");
        assertEquals("Documents are uploaded",ldi.saveDocuments(doc));
    }

	@Test
	public void testToUpdateSlotDLTest() {
		Appointment app = new Appointment();
		app.setAppointmentNumber("123");
		app.setTimeSlot("9:50 AM");
		assertEquals("DL Slot updated", ldi.updateSlotDLTest(app) );

	}

	@Test
	public void testToUpdateSlotLLTest() {
		Appointment app = new Appointment();
		app.setAppointmentNumber("123");
		app.setTimeSlot("9:50 AM");
		assertEquals("LL Slot updated", ldi.updateSlotLLTest(app) );

	}

	@Test
	public void testAvailableSlots() {
		List<Appointment> list = new ArrayList<>();
		try {
			assertNotEquals(list, ldi.readAvailableSlots());;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testToUpdateLL() {
		Appointment app = new Appointment();
		app.setAppointmentNumber("1234");
		app.setTestDate(new Date());
		app.setTimeSlot("9:50 AM");
		assertEquals("Appointment created and waiting for RTO Officer's approval", ldi.updateLL(app));
	}

	@Test
	public void testToUpdateDL() {
		Appointment app = new Appointment();
		app.setAppointmentNumber("1234");
		app.setTestDate(new Date());
		app.setTimeSlot("9:50 AM");
		assertEquals("Appointment created and waiting for RTO Officer's approval", ldi.updateDL(app));
	}

	@Test
	public void testToCancelAppointment() {
		Appointment app = new Appointment();
		app.setAppointmentNumber("1234");
		app.setTestDate(new Date());
		app.setTimeSlot("9:50 AM");
		assertEquals("Appointment cancelled", ldi.cancelAppointment(app));
	}

}

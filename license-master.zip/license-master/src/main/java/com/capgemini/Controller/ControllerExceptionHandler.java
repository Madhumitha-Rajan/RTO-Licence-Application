package com.capgemini.Controller;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.capgemini.exception.ApplicationNotFoundException;
import com.capgemini.exception.CannotCheckChallanException;
import com.capgemini.exception.CannotGenerateDrivingLicenseException;
import com.capgemini.exception.CannotGenerateLearnerLicenseException;
import com.capgemini.exception.CannotUpdateApplicationException;
import com.capgemini.exception.ChallanWithVehicleNumberNotFoundException;
import com.capgemini.exception.DuplicateRequestException;
import com.capgemini.exception.DuplicateUserFoundException;
import com.capgemini.exception.InvalidLoginException;
import com.capgemini.exception.NoApprovedApplicationException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.exception.ValueNotFoundException;

@ControllerAdvice 
class ControllerExceptionHandler {
	@ExceptionHandler(value = DuplicateUserFoundException.class)
	public ResponseEntity<String> exception(DuplicateUserFoundException exception1){
		return new ResponseEntity<String>(exception1.getMessage(),HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(value = ConstraintViolationException.class)
	public ResponseEntity exception(ConstraintViolationException exception1){
		return new ResponseEntity("Appropriate email to be entered",HttpStatus.EXPECTATION_FAILED);
				}
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ResponseEntity exception(MethodArgumentNotValidException exception1){
		return new ResponseEntity("Appropriate email to be entered",HttpStatus.EXPECTATION_FAILED);
				}
	
	
	@ExceptionHandler(value = ValueNotFoundException.class)
	public ResponseEntity<String> exception1(ValueNotFoundException exception1){
		return new ResponseEntity<String>(exception1.getMessage(),HttpStatus.NOT_FOUND);
		
		}
	@ExceptionHandler(value=InvalidLoginException.class)
	 public ResponseEntity<String> handleexception(InvalidLoginException exception){
		 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
	 }
@ExceptionHandler(value=NoApprovedApplicationException.class)
public ResponseEntity<String> handleexception(NoApprovedApplicationException exception){
	 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=ChallanWithVehicleNumberNotFoundException.class)
public ResponseEntity<String> handleexception(ChallanWithVehicleNumberNotFoundException exception){
	 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=NoPendingApplicationException.class)
public ResponseEntity<String> exception1(NoPendingApplicationException exception){
	 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=NoRejectedApplicationException.class)
public ResponseEntity<String> exception2(NoRejectedApplicationException exception){
	 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=ApplicationNotFoundException.class)
public ResponseEntity<String> exception2(ApplicationNotFoundException exception){
	 return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=CannotUpdateApplicationException.class)
public ResponseEntity<String> handleexception(CannotUpdateApplicationException exception)
{
	return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=CannotGenerateDrivingLicenseException.class)
public ResponseEntity<String> handleexception1(CannotGenerateDrivingLicenseException exception )
{
	return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=CannotGenerateLearnerLicenseException.class)
public ResponseEntity<String> handleexception2(CannotGenerateLearnerLicenseException exception )
{
	return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}
@ExceptionHandler(value=CannotCheckChallanException.class)
public ResponseEntity<String> handleexception3(CannotCheckChallanException exception )
{
	return new ResponseEntity<String>(exception.getMessage(),HttpStatus.NOT_FOUND);
}


@ExceptionHandler(value = DuplicateRequestException.class)
public ResponseEntity<String> exception(DuplicateRequestException ex){
	return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
}
}

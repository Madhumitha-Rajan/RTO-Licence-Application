package com.capgemini.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.AppointmentNotFoundException;
import com.capgemini.exception.DuplicateRequestException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidDocumentException;
import com.capgemini.exception.NoChallanException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Documents;
import com.capgemini.service.LicenseService;

@Validated
@RestController
public class LicenseController {

	@Autowired
	LicenseService service;
	@PostMapping("/AddLL")
	public ResponseEntity<String> createLL(@Valid @RequestBody Application llApplication) throws DuplicateRequestException {
		service.applyForLL(llApplication);
		return new ResponseEntity<String>("License Request added Successfully",HttpStatus.OK);
		}
	@PostMapping("/AddDL")
	public ResponseEntity<String> createDL(@Valid @RequestBody Application llApplication) throws DuplicateRequestException {
		service.applyForDL(llApplication);
		return new ResponseEntity<String>("License Request added Successfully",HttpStatus.OK);
		}
	@PostMapping("/AddDocuments")
	public String saveDocuments(@RequestBody Documents documents) throws InvalidDocumentException {
		service.uploadDocuments(documents);
		return "Documents uploaded Successfully";
		}
   @GetMapping("/findChallan/{vehicleNumber}")
   public ResponseEntity<String> findChallan(String vehicleNumber) throws NoChallanException {
	   String str = service.checkChallanByVehicleNumber(vehicleNumber);
	   if(str!=null)
	   {
		   return new ResponseEntity(str,HttpStatus.OK);
	   }
	   
	   
	   return new ResponseEntity("Vehicle Number is not found",HttpStatus.NOT_FOUND);
   }
   @GetMapping("/payChallan/{vehicleNumber}")
   public ResponseEntity<String> findChallanToPay(String vehicleNumber) throws NoChallanException {
	   String str = service.payChallanByVehicleNumber(vehicleNumber);
	   if(str!=null)
	   {
		   return new ResponseEntity(str,HttpStatus.OK);
	   }
	   
	   
	   return new ResponseEntity("Vehicle Number is not found",HttpStatus.NOT_FOUND);
   }
   @ExceptionHandler(value = NoChallanException.class)
	public ResponseEntity<String> handleException(NoChallanException exception) {
		return new ResponseEntity(exception.getMessage(), HttpStatus.NOT_FOUND);
	}

	@PostMapping("/email/{email}")
	public String emailFeesReceipt(@PathVariable("email") String email) throws FailedToSendEmailException {

		return service.emailFeesReceipt(email);

	}

	@PostMapping("/slot/LL")
	public String bookSlotLLTest(@RequestBody Appointment ap) {
		return service.bookSlotLLTest(ap);
		// return "Slot is booked";

	}

	@PostMapping("/slot/DL")
	public String bookSlotDLTest(@RequestBody Appointment ap) {
		return service.bookSlotLLTest(ap);
	}

	@GetMapping("/slots")
    public ResponseEntity<List<String>> readSlots() {
        List<String> list =  service.getAvailableSlots();
        if(list.isEmpty())
            return new ResponseEntity<List<String>>(list, HttpStatus.BAD_REQUEST);
        else
            return new ResponseEntity<List<String>>(list, HttpStatus.OK);
    }
	
	@PostMapping("/renew/DL")
	public String renewDL(@RequestBody Application app) {
		return service.renewDL(app);

	}

	@PostMapping("/renew/LL")
	public String renewLL(@RequestBody Application app) {
		return service.renewDL(app);

	}

	@DeleteMapping("/delete/{AppointmentNumber}")
    public String cancelAppointment(@PathVariable String AppointmentNumber) throws AppointmentNotFoundException {
	       return service.cancelAppointment(AppointmentNumber);
    }
	
	@ExceptionHandler(value = FailedToSendEmailException.class)
	public ResponseEntity<String> handleException(FailedToSendEmailException exception) {
		return new ResponseEntity(exception.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = AppointmentNotFoundException.class)
	public ResponseEntity<String> handleException(AppointmentNotFoundException exception) {
		return new ResponseEntity(exception.getMessage(), HttpStatus.NOT_FOUND);
	}

}

package com.capgemini.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.ApplicationNotFoundException;
import com.capgemini.exception.CannotCheckChallanException;
import com.capgemini.exception.CannotGenerateDrivingLicenseException;
import com.capgemini.exception.CannotGenerateLearnerLicenseException;
import com.capgemini.exception.CannotUpdateApplicationException;
import com.capgemini.exception.ChallanWithVehicleNumberNotFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidLoginException;
import com.capgemini.exception.NoApprovedApplicationException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Challan;
import com.capgemini.model.DrivingLicense;
import com.capgemini.model.RTOOfficer;
import com.capgemini.service.RTOOfficerService;
@RestController

public class RTOController {
	@Autowired
  public RTOOfficerService service;
	
	@PostMapping("/officer")
    public ResponseEntity<String> RTOOfficeLogin(@RequestBody RTOOfficer officer) throws InvalidLoginException
    {
        String k=service.officeLogin(officer);
        ResponseEntity<String> res;
        if(k.equalsIgnoreCase("ADDED TO DATABASE"))
        {
            res = new ResponseEntity<String>("ADDED TO DATABASE",
                    HttpStatus.OK);
        }
        else
            {
            res = new ResponseEntity<String>("Enter valid Details.",
                HttpStatus.INTERNAL_SERVER_ERROR);
            }
        return res;
    }
    @GetMapping("/login/{email}")
    public ResponseEntity<String> validateLogin(@PathVariable String email) throws InvalidLoginException
    {
        String k=service.validateRtoLogin(email);
        ResponseEntity<String> res;
        if(k.equalsIgnoreCase("VALID Login"))
        {
            res = new ResponseEntity<String>("VALID LOGIN",
                    HttpStatus.OK);
        }
        else
            {
            res = new ResponseEntity<String>("NOT A VALID USER.Enter valid Details.",
                HttpStatus.INTERNAL_SERVER_ERROR);
            }
        return res;
    }
   @GetMapping("/pendingApplications")
   public  ResponseEntity<List<Application>>  findAllPendingApplication() throws NoPendingApplicationException
   {
	   List<Application> list=service.viewAllPendingApplications();
	  if(list==null)
	  {
			return new ResponseEntity("Application Not Found",HttpStatus.NOT_FOUND);
	  }
	  return new  ResponseEntity<List<Application>>(list,HttpStatus.OK);
   }
   @PostMapping("/AddChallan")
   public ResponseEntity<String> createChallan(@RequestBody Challan challan) {
       service.createChallan(challan);
       return new ResponseEntity<String>("Challan details Added",HttpStatus.OK);
       }
   @GetMapping("/approvedApplications")
   public ResponseEntity<List<Application>> findAllApprovedApplication() throws NoApprovedApplicationException
   {
	   List<Application> list=service.viewAllApprovedApplications();
	   if(list==null)
		  {
				return new ResponseEntity("Application Not Found",HttpStatus.NOT_FOUND);
		  }
		  return new ResponseEntity<List<Application>>(list,HttpStatus.OK);
   }
   @GetMapping("/rejectedApplications")
   public ResponseEntity<List<Application>> findAllRejectedApplication() throws NoRejectedApplicationException
   {
	   List<Application> list=service.viewAllRejectedApplications();
	   if(list==null)
		  {
				return new ResponseEntity("Application Not Found",HttpStatus.NOT_FOUND);
		  }
		  return new ResponseEntity<List<Application>>(list,HttpStatus.OK);
   }
   @PutMapping("/testResult/{appointmentNumber}")
   public ResponseEntity<String> updateAppointmentById(@PathVariable String appointmentNumber,@RequestBody Appointment app) throws ApplicationNotFoundException
   {
       String a=service.updateTestResult(appointmentNumber,app);
       if(a==null)
       {
           return new ResponseEntity("Appointment Not Found",HttpStatus.NOT_FOUND);
       }
       return new ResponseEntity<String>("TestStatus is Updated",HttpStatus.OK);
   }
   @GetMapping("application/{applicationNumber}")
   public ResponseEntity<Application> findApplicationByNumber(@PathVariable String applicationNumber) throws  ApplicationNotFoundException 
   {
	   Application a=service.viewApplicationById(applicationNumber);
	   if(a==null)
	   {
		   return new ResponseEntity("Application For this application number is not found",HttpStatus.NOT_FOUND);
	   }
	   return new ResponseEntity<Application>(a,HttpStatus.OK);
   }
   @GetMapping("challan/{vehicleNumber}") 
   public ResponseEntity<String> findChallanByVehicleNumber(String vehicleNumber) throws ChallanWithVehicleNumberNotFoundException
   {
	   String str=service.checkChallanByVehicleNumber(vehicleNumber);
	   if(str==null)
	   {
			return new ResponseEntity("Vehicle Number is Not Found",HttpStatus.NOT_FOUND);
	   }
	   return new ResponseEntity<String>(str,HttpStatus.OK);
   }
 //http://localhost:9090/rtoofficer/findApplicationById
 	@PutMapping("/modifyApplicationById/{applicationNumber}")
 	public ResponseEntity< Application> modifyTestResultById(@PathVariable String applicationNumber,@RequestBody Application app) throws CannotUpdateApplicationException
 	{
 		Application application=service.modifyTestResultById(applicationNumber,app);
 		
 		if(application==null)
 		{
 			return new ResponseEntity("Application Cannot be updated",HttpStatus.NOT_FOUND);
 		}
 		else
 		{
 			return new ResponseEntity<Application>(application, HttpStatus.OK);
 		}
 		
 	}
 	
 	//http://localhost:9090/rtoofficer/generateDrivingLicense
 	@GetMapping("/generateDrivingLicense/{applicationNumber}")
 	public ResponseEntity<DrivingLicense> generateDrivingLicense(@PathVariable String applicationNumber) throws CannotGenerateDrivingLicenseException
 	{
 		DrivingLicense drivinglicense=service.generateDrivingLicense(applicationNumber);
 		if(drivinglicense==null)
 		{
 		  return new ResponseEntity("Driving License cannot be created",HttpStatus.NOT_FOUND);
 		}
 		else
 		{
 		  return new ResponseEntity<DrivingLicense>(drivinglicense,HttpStatus.OK);
 		}
 	}
 	
 	//http://localhost:9090/rtoofficer/generateLearnerLicense
 	@GetMapping("/generateLearnerLicense/{applicationNumber}")
 	public ResponseEntity<String> generateLearnerLicense(@PathVariable String applicationNumber)throws CannotGenerateLearnerLicenseException
 	{
 		String learnerlicense=service.generateLearnerLicense(applicationNumber);
 		if(learnerlicense==null)
 		{
 		return new ResponseEntity("Learner License cannot be generated",HttpStatus.NOT_FOUND);
 		}
 		else
 		{
 		return new ResponseEntity<String>(learnerlicense,HttpStatus.OK);
 		}  
 	}
 	
 	//http://localhost:9090/rtoofficer/generateEmailLicense
 	@PostMapping("/emailLicense/{email1}")
 	public String emailLicense(@PathVariable String email1)throws FailedToSendEmailException
 	{
 		String email=service.emailLicense(email1);
 		ResponseEntity<String> responseentity;
 		return email;
 	}
 	
 	//http://localhost:9090/rtoofficer/checkchallan
 	@GetMapping("/checkchallan")
 	public ResponseEntity<List<Challan>> checkAllChallan() throws CannotCheckChallanException
 	{
 		List<Challan> challan=service.checkAllChallan();
 		ResponseEntity<List<Challan>> responseentity;
 		if(challan!=null)
 		{
 			responseentity=new ResponseEntity<List<Challan>>(challan,HttpStatus.CREATED);
 		}
 		else
 		{
 			responseentity=new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
 		}
 		return responseentity;
 	}
}

package com.capgemini.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.DuplicateUserFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.ValueNotFoundException;
import com.capgemini.model.User;
import com.capgemini.service.UserService;

@Validated
@RestController
public class UserController {

	@Autowired
	UserService service;
	
	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping("/AddUser")
	public String addUser(@Valid @RequestBody User user) throws DuplicateUserFoundException, FailedToSendEmailException {
		if (service.userRegistration(user) != null)
			return "User is added";
		else
			return "User is not added";

	}
	
	@GetMapping("/UserByEmail/{email}")
	public ResponseEntity<User> findUserByEmail(@PathVariable String email) throws ValueNotFoundException{
		User user1 = service.userLogin(email);
		if(user1==null)
			return new ResponseEntity("User not found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<User>(user1,HttpStatus.OK);

	}
	
	@PutMapping("/UserUpdate/{email}")
	public ResponseEntity<String> updateUser(@PathVariable String email,@RequestBody User user)  throws ValueNotFoundException{
		String newpassword = user.getPassword();
		String user1 = service.changePassword(email,newpassword,user);
		if(user1 != null);
			return new ResponseEntity<String>("Updated Details",HttpStatus.OK);
		
		//return new ResponseEntity("User not found",HttpStatus.NOT_FOUND);
		}
	
	@GetMapping("/forgotPassword/{email}")
	public ResponseEntity<String> forgotPassword(@PathVariable String email) throws ValueNotFoundException {

		String response = service.forgotPassword(email);

		if(response !=null)
			return new ResponseEntity(response,HttpStatus.OK);
		return new ResponseEntity<String>("Enter valid email",HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/generateOtp")
	public ResponseEntity<String> generateOtp() throws ValueNotFoundException {

		String response = service.generateOtp();

		if(response !=null)
			return new ResponseEntity(response,HttpStatus.OK);
		return new ResponseEntity<String>("Enter valid email",HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/sendOtp/{email}")
	public ResponseEntity<String> sendOtp(@PathVariable String email) throws FailedToSendEmailException {

		String response = service.sendOtp(email);

		if(response !=null)
			return new ResponseEntity(response,HttpStatus.OK);
		return new ResponseEntity<String>("Enter valid email",HttpStatus.NOT_FOUND);
	}
	
	
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = DuplicateUserFoundException.class)
	public ResponseEntity<String> handleException(DuplicateUserFoundException exception) {
		return new ResponseEntity(exception.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(value=ValueNotFoundException.class)
	@ResponseStatus(code=HttpStatus.INTERNAL_SERVER_ERROR,reason="Duplicate employee found")
	public void handleException2(ValueNotFoundException e) {
		
	}
	
}

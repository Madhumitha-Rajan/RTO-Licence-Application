package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class MainUI {

	public static void main(String[] args) {
		
		SpringApplication.run(MainUI.class, args);
	}

}

package com.capgemini.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.model.Application;

public interface ApplicationDao extends JpaRepository<Application, String>{

	public Application findByApplicationNumber(String applicationNumber);
	
}

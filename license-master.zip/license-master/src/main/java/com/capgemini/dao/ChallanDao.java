package com.capgemini.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.model.Challan;

public interface ChallanDao extends JpaRepository<Challan, String> {
	@Query("Select c.challanNumber from Challan c where c.vehicleNumber=?1")
	public String findByVehicleNumber(String vehicleNumber);

	@Query("Select c from Challan c")
	public List<Challan> findAllChallan();
	
	@Query("Select c.amount from Challan c where c.vehicleNumber=?1")
	public String findByAmount(String vehicleNumber);
}

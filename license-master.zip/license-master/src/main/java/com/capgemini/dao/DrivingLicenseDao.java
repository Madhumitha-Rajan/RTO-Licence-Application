package com.capgemini.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.model.DrivingLicense;

public interface DrivingLicenseDao extends JpaRepository<DrivingLicense,String>{
	
}

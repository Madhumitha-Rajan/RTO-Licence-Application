package com.capgemini.dao;

import java.text.ParseException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.exception.*;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Documents;


public interface LicenseDao extends JpaRepository<Appointment, String> {

	Appointment findByAppointmentNumber(String appointment_Number);
	
	
}
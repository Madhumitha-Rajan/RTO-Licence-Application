package com.capgemini.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.exception.NoApprovedApplicationException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.model.Application;
import com.capgemini.model.RTOOfficer;
@Repository
public interface RTOOfficerDao extends JpaRepository<RTOOfficer, String> {
	 @Query("Select a from Application a where a.status='PENDING'")
	 List<Application> findAllPendingApplication() throws NoPendingApplicationException;
	 @Query("Select a from Application a where a.status='APPROVED'")
	 List<Application> findAllApprovedApplication() throws NoApprovedApplicationException;
	 @Query("Select a from Application a where a.status='REJECTED'")
	 List<Application> findAllRejectedApplication() throws NoRejectedApplicationException;
	 @Query("Select a from Application a where a.applicationNumber=?1")
	 Application findByApplicationNumber(String applicationNumber);
	 @Query("Select c.challanNumber from Challan c where c.vehicleNumber=?1")
	 String findChallanByVehicle(String vehicleNumber);
	RTOOfficer findByEmail(String email);
}

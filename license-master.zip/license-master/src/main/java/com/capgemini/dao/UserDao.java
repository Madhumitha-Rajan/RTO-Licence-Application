package com.capgemini.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.exception.ValueNotFoundException;
import com.capgemini.model.User;

public interface UserDao extends JpaRepository<User,Integer>{

	public User findByEmail(String email) throws ValueNotFoundException;
	
	
	
}

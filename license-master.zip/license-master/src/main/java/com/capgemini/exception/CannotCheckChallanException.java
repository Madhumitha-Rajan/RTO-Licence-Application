package com.capgemini.exception;

public class CannotCheckChallanException extends Exception {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6571363629147977L;

	public CannotCheckChallanException(String string)
	{
		super(string);
	}
}

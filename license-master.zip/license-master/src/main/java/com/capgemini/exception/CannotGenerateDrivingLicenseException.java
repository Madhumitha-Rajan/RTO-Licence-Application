package com.capgemini.exception;

public class CannotGenerateDrivingLicenseException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 2365342784037099323L;

	public CannotGenerateDrivingLicenseException(String string) {
		super(string);
	}

}

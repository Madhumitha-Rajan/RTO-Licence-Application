package com.capgemini.exception;

public class CannotGenerateLearnerLicenseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1236235134700331095L;

	public CannotGenerateLearnerLicenseException(String string) {
		super(string);
	}

}

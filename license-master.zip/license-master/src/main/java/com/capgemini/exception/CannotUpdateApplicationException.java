package com.capgemini.exception;

public class CannotUpdateApplicationException extends Exception {


	private static final long serialVersionUID = 3623087733939292766L;

	
	
	public CannotUpdateApplicationException(String string) {
		super(string);
	}
	
}

package com.capgemini.exception;

public class DuplicateRequestException extends Exception {

	public DuplicateRequestException(String string) {
		super(string);
	}

}

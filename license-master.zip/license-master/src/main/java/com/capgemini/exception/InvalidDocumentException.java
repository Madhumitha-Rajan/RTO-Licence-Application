package com.capgemini.exception;

public class InvalidDocumentException extends Exception {

	public InvalidDocumentException(String string) {
		super(string);
	}

}

package com.capgemini.exception;

public class NoApprovedApplicationException extends Exception {

	public NoApprovedApplicationException(String msg) {
		super(msg);
	}
}

package com.capgemini.exception;

public class NoChallanException extends Exception {
   public NoChallanException(String s) {
	   super(s);
   }
}

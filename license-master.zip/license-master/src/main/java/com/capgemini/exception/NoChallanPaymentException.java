package com.capgemini.exception;

public class NoChallanPaymentException extends Exception {
 public NoChallanPaymentException(String str1) {
	 super(str1);
 }
}

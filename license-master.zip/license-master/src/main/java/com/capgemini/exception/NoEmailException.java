package com.capgemini.exception;

public class NoEmailException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7075199626153039963L;

	
	public NoEmailException(String string)
	{
		super(string);
	}
}

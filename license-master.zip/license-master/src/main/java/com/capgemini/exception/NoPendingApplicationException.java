package com.capgemini.exception;

public class NoPendingApplicationException extends Exception {

	public NoPendingApplicationException(String msg) {
		super(msg);
	}
}

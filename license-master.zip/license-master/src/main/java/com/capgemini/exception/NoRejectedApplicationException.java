package com.capgemini.exception;

public class NoRejectedApplicationException extends Exception {

	public NoRejectedApplicationException(String msg) {
		super(msg);
	}
}

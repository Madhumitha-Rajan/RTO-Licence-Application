package com.capgemini.exception;

public class ValueNotFoundException extends Exception {
	public ValueNotFoundException(Exception e) {
		super(e);
	}

	public ValueNotFoundException(String string) {
		super(string);
	}
}

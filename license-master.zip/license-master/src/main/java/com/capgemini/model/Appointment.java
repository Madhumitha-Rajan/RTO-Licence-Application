package com.capgemini.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Appointment_table")
public class Appointment implements Serializable {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private String appointmentNumber;
	@Column(name = "test_date")
	private Date testDate;
	@Column(name = "test_slot")
	private String timeSlot;
	@Column(name = "test_result")
	private String testResult;
	@OneToOne(cascade = CascadeType.ALL,orphanRemoval = true)
	private RTOOfficer approver;
	@Enumerated(value = EnumType.STRING)
	private	AppointmentStatus appStatus;
	public AppointmentStatus getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(AppointmentStatus appStatus) {
		this.appStatus = appStatus;
	}

	private static final long serialVersionUID = 1L;

	public Appointment(String appointmentNumber, Date testDate, String timeSlot, String testResult) {
		super();
		this.appointmentNumber = appointmentNumber;
		this.testDate = testDate;
		this.timeSlot = timeSlot;
		this.testResult = testResult;
		
	}

	public Appointment() {
		// TODO Auto-generated constructor stub
	}

	// LL - Online Test. DL - Driving Test
	// RTO officer has to set the test result because conducting test is out of
	// scope
	
	// getters and setters

	public String getAppointmentNumber() {
		return appointmentNumber;
	}

	public void setAppointmentNumber(String appointmentNumber) {
		this.appointmentNumber = appointmentNumber;
	}

	public Date getTestDate() {
		return testDate;
	}

	public void setTestDate(Date testDate) {
		this.testDate = testDate;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public String getTestResult() {
		return testResult;
	}

	public void setTestResult(String testResult) {
		this.testResult = testResult;
	}

	public RTOOfficer getApprover() {
		return approver;
	}

	public void setApprover(RTOOfficer approver) {
		this.approver = approver;

	}
}
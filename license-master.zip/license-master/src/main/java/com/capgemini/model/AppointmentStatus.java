package com.capgemini.model;

public enum AppointmentStatus {
	APPROVED,CANCELLED
}

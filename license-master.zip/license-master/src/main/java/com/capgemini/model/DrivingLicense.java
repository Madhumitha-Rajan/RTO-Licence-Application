package com.capgemini.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DrivingLicense_table")
public class DrivingLicense {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private String drivingLicenseNumber;
	@OneToOne(cascade = CascadeType.ALL)
	private Application application;
	private Date dateOfIssue;
	private Date validTill;
	@OneToOne(cascade = CascadeType.ALL)
	private RTOOffice issuedBy;
	public String getDrivingLicenseNumber() {
		return drivingLicenseNumber;
	}
	public void setDrivingLicenseNumber(String drivingLicenseNumber) {
		this.drivingLicenseNumber = drivingLicenseNumber;
	}
	public Application getApplication() {
		return application;
	}
	public void setApplication(Application application) {
		this.application = application;
	}
	public Date getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	public Date getValidTill() {
		return validTill;
	}
	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}
	public RTOOffice getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(RTOOffice issuedBy) {
		this.issuedBy = issuedBy;
	}
	
}

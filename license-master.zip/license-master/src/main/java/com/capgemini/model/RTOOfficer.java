package com.capgemini.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "RTOOfficer_table")
public class RTOOfficer {
	@Id
	@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$",message = "Appropriate email need to be entered")
	private String email;
	@OneToOne(cascade = CascadeType.ALL,orphanRemoval = true)
	private RTOOffice office;
	@Column(name = "username")
	private String username;
	@Column(name = "password")
	private String password;
	public RTOOfficer(String email, String username, String password) {
		super();
		this.email = email;
		this.username = username;
		this.password = password;
	}
	public RTOOfficer() {
		
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public RTOOffice getOffice() {
		return office;
	}
	public void setOffice(RTOOffice office) {
		this.office = office;
	}
	
}

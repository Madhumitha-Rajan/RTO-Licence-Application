package com.capgemini.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.Parameter;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("user")
@Scope(scopeName = "prototype")
@Entity
@Table(name ="users")
public class User  {
	
	
	@Id
	@Column(name = "user_email")
	
	@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$",message = "Appropriate email need to be entered")
	private String email;
	@Column(name = "user_password")
	@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)$",message = "Enter valid password")
	private String password;
	public User(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public User() {
		
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}

package com.capgemini.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.ChallanDao;
import com.capgemini.dao.DocumentDao;
import com.capgemini.dao.LicenseDao;
import com.capgemini.dao.LicenseDao2;
import com.capgemini.exception.AppointmentNotFoundException;
import com.capgemini.exception.DuplicateRequestException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidDocumentException;
import com.capgemini.exception.NoChallanException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.AppointmentStatus;
import com.capgemini.model.Challan;
import com.capgemini.model.Documents;



@Service
public class LicenceServiceImpl implements LicenseService {

	@Autowired
	private LicenseDao dao;
	@Autowired
	private LicenseDao2 licenseDao;
	@Autowired
	private DocumentDao dao1;
	@Autowired
	private ChallanDao dao2;

	@Override
	public String applyForLL(Application llApplication) throws DuplicateRequestException {

		if (llApplication != null) {
			licenseDao.save(llApplication);

			return "LearnerLicense request Created";
		} else
			throw new DuplicateRequestException("Duplicate License Request found");
	}

	@Override
	public String applyForDL(Application dlApplication) throws DuplicateRequestException {

		if (dlApplication != null) {
			licenseDao.save(dlApplication);

			return "DrivingLicense request Created";
		} else
			throw new DuplicateRequestException("Duplicate License Request found");
	}

	@Override
	public String uploadDocuments(Documents documents) throws InvalidDocumentException {
		if (documents != null) {
			dao1.save(documents);

			return "Documents are uploaded successfully";
		} else
			throw new InvalidDocumentException("Invalid type Document included");
	}

	@Override
    public String checkChallanByVehicleNumber(String vehicleNumber) throws NoChallanException {
        String str=dao2.findByVehicleNumber(vehicleNumber);
        if(str!=null)
        {
            return str;
        }
        throw new NoChallanException("Vehicle Number is Not Found");
    }  
 

   
	@Override
	public String emailFeesReceipt(String email) throws FailedToSendEmailException {

		String str = "";
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("rto.officeindia3@gmail.com", "Qwerty@123");
			}
		});
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom();
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			message.setSubject("Fee Receipt");
			message.setContent("YOU HAVE SUCCESSFULLY PAID FOR LICENSE", "text/html");
			// send message
			Transport.send(message);
			str = "Successfully sent email!";
			return str;
		} catch (Exception e) {
			throw new FailedToSendEmailException("unable to send email");
		}

	}

	@Override
	public String bookSlotLLTest(Appointment appointment) {

		if (appointment != null) {
			dao.save(appointment);
			return "successfully booked";
		}
		return "failed to book";

	}

	@Override
	public String bookSlotDLTest(Appointment appointment) {

		if (appointment != null) {
			dao.save(appointment);
			return "successfully booked";
		}
		return "failed to book";
	}
	public List<String> getAvailableSlots() {
        List<String> timeSlots = new ArrayList<>();
        String timeSlot1 = "10:00 AM";
        String timeSlot2 = "12:00 PM";
        String timeSlot3 = "3:00 PM";

 

        Date today;
        String output;
        SimpleDateFormat formatter;
        String pattern = "EEE, dd.MM.yy";
        String[] holidaysList = {"25.12.20"};

 

        formatter = new SimpleDateFormat(pattern);
        today = new Date();
        output = formatter.format(today);
        if (today.getDay() == 7) {
            return timeSlots;
        }
        for (int i = 0; i < holidaysList.length; i++) {
            if (output.contains(holidaysList[i])) {
                System.out.println("today is holiday ");
                return timeSlots;
            }
        }
        timeSlots.add(output+" "+timeSlot1);
        timeSlots.add(output+" "+timeSlot2);
        timeSlots.add(output+" "+timeSlot3);
        return timeSlots;
    }

	@Override
	public String renewLL(Application llApplication) {
		if (llApplication != null) {
			dao.save(llApplication.getAppointment());
			return "Appointment created for renewal";
		}
		return "Failed to create appointment";
	}

	@Override
	public String renewDL(Application dlApplication) {
		if (dlApplication != null) {
			dao.save(dlApplication.getAppointment());
			return "Appointment created for renewal";
		}
		return "Failed to create appointment";
	}

	

	@Override
	public String cancelAppointment(String appointmentNumber) throws AppointmentNotFoundException {
		Appointment ap = dao.findByAppointmentNumber(appointmentNumber);
		if(ap !=null) {      
        	ap.setAppStatus(AppointmentStatus.CANCELLED);
        	dao.save(ap);
        	return "Appointment Cancelled";
        }		
        else
         throw new AppointmentNotFoundException("Not found");
		
   
	}

	@Override
    public String payChallanByVehicleNumber(String vehicleNumber) throws NoChallanException {
        String str =dao2.findByVehicleNumber(vehicleNumber);
        
        if(str!=null)
        {           
            return "Challan Fee = "+dao2.findByAmount(vehicleNumber);
        }
   
   
   throw new NoChallanException("Challan doesn't Exists");
}

	@Override
	public String payFees(int amount) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

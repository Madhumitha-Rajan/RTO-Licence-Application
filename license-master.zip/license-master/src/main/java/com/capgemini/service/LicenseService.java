package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.AppointmentNotFoundException;
import com.capgemini.exception.DuplicateRequestException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidDocumentException;
import com.capgemini.exception.NoChallanException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Challan;
import com.capgemini.model.Documents;

public interface LicenseService {
	public String applyForLL(Application llApplication) throws DuplicateRequestException;
	public String applyForDL(Application dlApplication) throws DuplicateRequestException;
	public String uploadDocuments(Documents documents) throws InvalidDocumentException;
	public String checkChallanByVehicleNumber(String vehicleNumber) throws NoChallanException;
	public String payChallanByVehicleNumber(String vehicleNumber) throws NoChallanException;
	public String payFees(int amount);
	
	
	public String emailFeesReceipt(String email) throws FailedToSendEmailException;
	public String bookSlotLLTest(Appointment appointment);
	public String bookSlotDLTest(Appointment appointment);
	public List<String> getAvailableSlots();
	public String renewLL(Application llApplication);
	public String renewDL(Application dlApplication);
	public String cancelAppointment(String appointmentNumber) throws AppointmentNotFoundException;
	
}
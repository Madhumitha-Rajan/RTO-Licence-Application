package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.ApplicationNotFoundException;
import com.capgemini.exception.CannotCheckChallanException;
import com.capgemini.exception.CannotGenerateDrivingLicenseException;
import com.capgemini.exception.CannotGenerateLearnerLicenseException;
import com.capgemini.exception.CannotUpdateApplicationException;
import com.capgemini.exception.ChallanWithVehicleNumberNotFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidLoginException;
import com.capgemini.exception.NoApprovedApplicationException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Challan;
import com.capgemini.model.DrivingLicense;
import com.capgemini.model.RTOOfficer;

public interface RTOOfficerService {
	//public void add1(Application app);
	public String officeLogin(RTOOfficer officer) throws InvalidLoginException;
	public List<Application> viewAllPendingApplications() throws NoPendingApplicationException;
	public List<Application> viewAllRejectedApplications() throws NoRejectedApplicationException;
	public List<Application> viewAllApprovedApplications() throws NoApprovedApplicationException;
	public Application viewApplicationById(String applicationNumber) throws  ApplicationNotFoundException ;
	public String checkChallanByVehicleNumber(String vehicleNumber) throws ChallanWithVehicleNumberNotFoundException;
	//public Application modifyTestResultById(String applicationNumber) throws CannotUpdateApplicationException;
	public String generateLearnerLicense(String applcationNumber) throws CannotGenerateLearnerLicenseException;
	public DrivingLicense generateDrivingLicense(String applcationNumber) throws CannotGenerateDrivingLicenseException;
	public String emailLicense(String email) throws FailedToSendEmailException;
	public List<Challan> checkAllChallan() throws CannotCheckChallanException;
	public Application modifyTestResultById(String applicationNumber, Application app1)
			throws CannotUpdateApplicationException;
	public String validateRtoLogin(String email) throws InvalidLoginException;
	
	public String updateTestResult(String AppointmentNumber, Appointment app) throws ApplicationNotFoundException;
	public String createChallan(Challan challan);
	
}

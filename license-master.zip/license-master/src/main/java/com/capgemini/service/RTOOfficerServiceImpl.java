package com.capgemini.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.ApplicationDao;
import com.capgemini.dao.ChallanDao;
import com.capgemini.dao.DrivingLicenseDao;
import com.capgemini.dao.LicenseDao;
import com.capgemini.dao.RTOOfficerDao;
import com.capgemini.exception.ApplicationNotFoundException;
import com.capgemini.exception.CannotCheckChallanException;
import com.capgemini.exception.CannotGenerateDrivingLicenseException;
import com.capgemini.exception.CannotGenerateLearnerLicenseException;
import com.capgemini.exception.CannotUpdateApplicationException;
import com.capgemini.exception.ChallanWithVehicleNumberNotFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidLoginException;
import com.capgemini.exception.NoApprovedApplicationException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.AppointmentStatus;
import com.capgemini.model.Challan;
import com.capgemini.model.DrivingLicense;
import com.capgemini.model.RTOOfficer;

import net.bytebuddy.utility.RandomString;

@Service
public class RTOOfficerServiceImpl implements RTOOfficerService {
	@Autowired
	private RTOOfficerDao dao;
	@Autowired
	private ApplicationDao applicationdao;
	@Autowired
	private DrivingLicenseDao drivingLicensedao;
	@Autowired
	private ChallanDao challandao;
	@Autowired
	private LicenseDao licensedao;
	
	@Override
    public String officeLogin(RTOOfficer officer) throws IllegalArgumentException, InvalidLoginException {
        String s = "";
        RTOOfficer r = dao.save(officer);
        if (r != null) {
            return "ADDED TO DATABASE";
        } else {
            throw new InvalidLoginException("ENTER VALID DETAILS");
        }

 

    }

@Override    
    public String validateRtoLogin(String email) throws InvalidLoginException {

        RTOOfficer rto = dao.findByEmail(email);
        if (rto!=null) {
            return "VALID LOGIN";
        } else {
            throw new InvalidLoginException("NOT A VALID USER");
        }

 

    }

	@Override
	public List<Application> viewAllPendingApplications() throws NoPendingApplicationException {
		List<Application> app = dao.findAllPendingApplication();
		if (!app.isEmpty()) {
			return app;
		}
		// System.out.println("Not Found");
		throw new NoPendingApplicationException("Application is not found");
	}

	@Override
	public List<Application> viewAllRejectedApplications() throws NoRejectedApplicationException {
		List<Application> app = dao.findAllRejectedApplication();
		if (!app.isEmpty()) {
			return app;
		}
		throw new NoRejectedApplicationException("Application is not found");

	}

	@Override
	public List<Application> viewAllApprovedApplications() throws NoApprovedApplicationException {

		List<Application> app = dao.findAllApprovedApplication();
		if (!app.isEmpty()) {
			return app;
		}
		throw new NoApprovedApplicationException("Application is not found");
	}
	
	@Override
    public String updateTestResult(String AppointmentNumber,Appointment app) throws ApplicationNotFoundException{
        Appointment a= licensedao.findByAppointmentNumber(AppointmentNumber);
        if(a != null && a.getAppStatus().equals(AppointmentStatus.APPROVED))   {
        	licensedao.save(app);
             return "Test Result Updated";
        }
        throw new ApplicationNotFoundException("Appointment is not Found");
    }
	@Override
	public Application viewApplicationById(String applicationNumber) throws ApplicationNotFoundException {

		Application a = dao.findByApplicationNumber(applicationNumber);
		if (a != null) {
			return a;
		}
		throw new ApplicationNotFoundException("Application For this application number is not found");
	}

	@Override
	public String checkChallanByVehicleNumber(String vehicleNumber) throws ChallanWithVehicleNumberNotFoundException {
		String str=dao.findChallanByVehicle(vehicleNumber);
		if(str!=null)
		{
			return str;
		}
		throw new ChallanWithVehicleNumberNotFoundException("Vehicle Number is Not Found");
	}


	@Override
	public Application modifyTestResultById(String applicationNumber,Application app1) throws CannotUpdateApplicationException{
		
		if(applicationdao.existsById(applicationNumber))
		{
			applicationdao.save(app1);
			return app1;
			
		}
		throw new CannotUpdateApplicationException("Application can not be modified");
	}
	@Override
	public String generateLearnerLicense(String applicationNumber) throws CannotGenerateLearnerLicenseException {
		Application app = dao.findByApplicationNumber(applicationNumber);
		Date dob = app.getApplicant().getDateOfBirth();
		 //Converting obtained Date object to LocalDate object
		Instant instant = dob.toInstant();
	      ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
	      LocalDate givenDate = zone.toLocalDate();
	    //Calculating the difference between given date to current date.
	      Period period = Period.between(givenDate, LocalDate.now());
	      if(period.getYears() >18) {
	    	  return "Learner license generated";
	      }
		return "Cannot generate";
		
	}

	@Override
	public DrivingLicense generateDrivingLicense(String applicationNumber) throws CannotGenerateDrivingLicenseException {
		Application app = dao.findByApplicationNumber(applicationNumber);
		DrivingLicense dl1 = new DrivingLicense();		
		String res = app.getAppointment().getTestResult();
		String generatedString = RandomString.make();
		
		
			if(res.equalsIgnoreCase("passed")) {
			dl1.setApplication(app);
			dl1.setDateOfIssue(new Date());
			dl1.setDrivingLicenseNumber(generatedString);
			drivingLicensedao.save(dl1);
			return dl1;
			}
		
		throw new CannotGenerateDrivingLicenseException("DrivingLicense cannot be generated");
	}

	
	
	@Override
	public String emailLicense(String email)throws FailedToSendEmailException {
		String str = "";
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("rto.officeindia3@gmail.com", "Qwerty@123");
			}
		});
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom();
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			message.setSubject("Approved");
			message.setContent("YOUR LICENSE IS SUCCESSFULLY GENERATED", "text/html");
			// send message
			Transport.send(message);
			str = "Successfully sent email!";
			return str;
		} catch (Exception e) {
			throw new FailedToSendEmailException("unable to send email");
		}

	}
	@Override
    public String createChallan(Challan challan) {
        if (challan != null) 
            challandao.save(challan);
            return "Challan Details Added";
    }

	@Override
	public List<Challan> checkAllChallan() throws CannotCheckChallanException {
		List<Challan> ch = challandao.findAllChallan();
	
		if(ch != null)
		{
			return ch;
		}
		throw new CannotCheckChallanException("Challan Not Found") ;
	}
}

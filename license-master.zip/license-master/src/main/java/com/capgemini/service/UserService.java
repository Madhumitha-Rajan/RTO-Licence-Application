package com.capgemini.service;

import com.capgemini.exception.DuplicateUserFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.ValueNotFoundException;
import com.capgemini.model.User;

public interface UserService {
	public String userRegistration(User user) throws DuplicateUserFoundException, FailedToSendEmailException;

	public User userLogin(String email) throws ValueNotFoundException;


	public String forgotPassword(String email) throws ValueNotFoundException;

	public String generateOtp();

	public String sendOtp(String email) throws FailedToSendEmailException;

	public String changePassword(String email, String newPassword, User user) throws ValueNotFoundException;

}

package com.capgemini.service;

import java.text.DecimalFormat;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.UserDao;
import com.capgemini.exception.DuplicateUserFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.ValueNotFoundException;
import com.capgemini.model.User;

@Service("service")
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao dao;
	
	

	@Override
	public String userRegistration(User user) throws DuplicateUserFoundException, FailedToSendEmailException {
		User user1 = dao.save(user);
		if (user1 != null) {
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("rto.officeindia3@gmail.com", "Qwerty@123");
			}
		});
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom();
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(user1.getEmail()));
			message.setSubject("RTO WELCOMES YOU!");
			message.setContent("You have Successfully registered!!..You can now start using our services...", "text/html");
			// send message
			Transport.send(message);
		} catch (Exception e) {
			throw new FailedToSendEmailException("unable to send email");
		}
		}

		return "User with "+user.getEmail()+"not registered";
	}

	@Override
	public User userLogin(String email) throws ValueNotFoundException {
		try {
			User user1 = dao.findByEmail(email);
			return user1;
		} catch (Exception e) {
			throw new ValueNotFoundException(e);
		}
	}

	@Override
	public String changePassword(String email,String newPassword,User user) throws ValueNotFoundException {
		if(user.getEmail().equals(email)) {
			user.setPassword(newPassword);
			dao.save(user);
			return "User updated";
		}
		throw new ValueNotFoundException("Not updated");
			
	}

	@Override
	public String forgotPassword(String email) throws ValueNotFoundException {
			User user = dao.findByEmail(email);
			if(user!= null && user.getEmail().equals(email)) {
				return user.getPassword();
			}
			throw new ValueNotFoundException("No record found with this login");
	}

	@Override
	public String generateOtp() {
		String otp= new DecimalFormat("000000").format(new Random().nextInt(999999));
		return otp;
	}

	@Override
	public String sendOtp(String email) throws FailedToSendEmailException {
		String str = "";
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("rto.officeindia3@gmail.com", "Qwerty@123");
			}
		});
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom();
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			message.setSubject("Verification Email");
			message.setContent("Welcome to RTO Office!We are glad to have you.Here is your OTP "+generateOtp()+"for your Account Activation", "text/html");
			// send message
			Transport.send(message);
			str = "Successfully sent email!";
			return str;
		} catch (Exception e) {
			throw new FailedToSendEmailException("unable to send email");
		}
	}

	

}

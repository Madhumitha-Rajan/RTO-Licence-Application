package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capgemini.MainUI;
import com.capgemini.dao.ChallanDao;
import com.capgemini.dao.DocumentDao;
import com.capgemini.dao.LicenseDao;
import com.capgemini.dao.LicenseDao2;
import com.capgemini.exception.AppointmentNotFoundException;
import com.capgemini.exception.DuplicateRequestException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidDocumentException;
import com.capgemini.exception.NoChallanException;
import com.capgemini.model.Address;
import com.capgemini.model.Applicant;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.Challan;
import com.capgemini.model.Documents;
import com.capgemini.model.Gender;
import com.capgemini.service.LicenseService;

@SpringBootTest(classes = MainUI.class)
public class LicenseServiceImplTest{
	@Autowired
	private LicenseService service;
	@MockBean
	private LicenseDao2 dao;
	@MockBean
	private DocumentDao dao1;
	@MockBean
	private ChallanDao dao2;
	@MockBean
	private LicenseDao ldao;
	
	
	@Test
	void testAddRequestLLShouldAddUserDatatoDatabase() throws DuplicateRequestException, ParseException{
		Application app = new Application();
		Applicant appl = new Applicant();
	    Address add = new Address();
		app.setApplicationNumber("102");
		app.setApplicationDate(new Date());
		appl.setFirstName("Jeev");
		appl.setLastName("Karakambadi");
		appl.setMobile("879645890");
		appl.setEmail("jeevu@gmail.com");
		String dateString = "01/08/1985";
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		appl.setDateOfBirth(formatter.parse(dateString));
		appl.setGender(Gender.FEMALE);
		appl.setNationality("Indian");
		appl.setPlaceOfBirth("tpt");
		appl.setQualification("btech");
		app.setApplicant(appl);
		add.setCity("tpt");
		add.setHouse("10-12/A");
		add.setLandmark("beside temple");
		add.setPincode("54321");
		add.setState("AP");
		add.setCity("nellore");
		add.setHouse("10-1/A");
		add.setLandmark("beside temple");
		add.setPincode("54311");
		add.setState("AP");
		appl.setPermanentAddress(add);
		appl.setPresentAddress(add);
		String str = "LearnerLicense request Created ";
		when(dao.save(app)).thenReturn(app);
		String result = service.applyForLL(app);
		assertEquals("LearnerLicense request Created",result);
	}
	
	@Test
	void testAddRequestDLShouldAddUserDatatoDatabase() throws DuplicateRequestException, ParseException{
		Application app = new Application();
		Applicant appl = new Applicant();
	    Address add = new Address();
		app.setApplicationNumber("132");
		app.setApplicationDate(new Date());
		appl.setFirstName("Jeeva");
		appl.setLastName("Karakambadi");
		appl.setMobile("879645890");
		appl.setEmail("jeevu@gmail.com");
		String dateString = "01/08/1985";
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		appl.setDateOfBirth(formatter.parse(dateString));
		appl.setGender(Gender.FEMALE);
		appl.setNationality("Indian");
		appl.setPlaceOfBirth("tpt");
		appl.setQualification("btech");
		app.setApplicant(appl);
		add.setCity("tpt");
		add.setHouse("10-12/A");
		add.setLandmark("beside temple");
		add.setPincode("54321");
		add.setState("AP");
		add.setCity("nellore");
		add.setHouse("10-1/A");
		add.setLandmark("beside temple");
		add.setPincode("54311");
		add.setState("AP");
		appl.setPermanentAddress(add);
		appl.setPresentAddress(add);
		String str = "DrivingLicense request Created ";
		when(dao.save(app)).thenReturn(app);
		String result = service.applyForDL(app);
		assertEquals("DrivingLicense request Created",result);
	}
	
	  @Test 
	  void testAddDocumentIntoDatabase() throws InvalidDocumentException {
	  Documents doc = new Documents();
	  
	  doc.setPhoto("ph1"); 
	  doc.setAddressProof("af1");
	  doc.setIdProof("If1");
	  
	  when(dao1.save(doc)).thenReturn(doc);
	  assertEquals("Documents are uploaded successfully", service.uploadDocuments(doc)); }
	 
	
	@Test
	public void testCheckChallanByVehiclenumberInDatabase() throws NoChallanException {

		Challan c = new Challan();
		c.setChallanNumber("T4A89");
		c.setVehicleNumber("14789");
		c.setAmount(2000.0);

		String str = c.getVehicleNumber();
		String st = c.getChallanNumber();
		when(dao2.findByVehicleNumber(str)).thenReturn(st);
		assertEquals(st, service.checkChallanByVehicleNumber(str));
	}
	@Test
	public void testToPayChallanByVehicleNumber() throws NoChallanException {

		Challan c = new Challan();
		c.setChallanNumber("AP479");
		c.setVehicleNumber("1479");
		c.setAmount(2030.0);

		String str = c.getVehicleNumber();
		String s = "The challan Amount = " + c.getAmount() + " has to pay ";
		when(dao2.findByVehicleNumber(str)).thenReturn(s);
		assertEquals(s, service.checkChallanByVehicleNumber(str));
	}
	/*
	 * @Test public void PaymentOfFeesForApplication() { Application apl = new
	 * Application(); apl.setAmountPaid(325.80); double db = apl.getAmountPaid();
	 * String str = "payment is Successfull";
	 * when(dao.findByAmountPaid(db)).thenReturn(str); assertEquals(str,
	 * service.payFees(db)); }
	 */
	@Test
	public void toTestBookSlotLLTest() {
		Appointment appointment = new Appointment("122", new Date(), "10:00 AM", "passed");
		when(ldao.save(appointment)).thenReturn(appointment);
		assertEquals("successfully booked", service.bookSlotLLTest(appointment));

	}

	@Test
	public void toTestBookSlotDLTest() {
		Appointment appointment = new Appointment("123", new Date(), "10:00 AM", "passed");
		when(ldao.save(appointment)).thenReturn(appointment);
		assertEquals("successfully booked", service.bookSlotLLTest(appointment));

	}

	@Test
	public void testToReadAvailableSlots() {

		assertNotNull(service.getAvailableSlots());
	}

	@Test
	public void testToRenewLL() {
		Appointment appointment = new Appointment("124", new Date(), "10:00 AM", "passed");
		Application app = new Application();
		app.setAppointment(appointment);
		when(ldao.save(appointment)).thenReturn(appointment);
		assertEquals("Appointment created for renewal", service.renewLL(app));

	}

	@Test
	public void testToRenewDL() {
		Appointment appointment = new Appointment("125", new Date(), "10:00 AM", "passed");
		Application app = new Application();
		app.setAppointment(appointment);
		when(ldao.save(appointment)).thenReturn(appointment);
		assertEquals("Appointment created for renewal", service.renewDL(app));

	}

	@Test
	public void testToCancelAppointment() throws AppointmentNotFoundException {
		Appointment appointment = new Appointment("125", new Date(), "10:00 AM", "passed");
		when(ldao.findByAppointmentNumber("125")).thenReturn(appointment);

		assertEquals("Appointment Cancelled", service.cancelAppointment("125"));
	}
	
	@Test
	public void testToEmailFeeReceipt() throws FailedToSendEmailException {
		assertEquals("Successfully sent email!", service.emailFeesReceipt("bollamgouthami9@gmail.com"));
	}
}
package com.capgemini.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capgemini.dao.ApplicationDao;
import com.capgemini.dao.ChallanDao;
import com.capgemini.dao.DrivingLicenseDao;
import com.capgemini.dao.RTOOfficerDao;
import com.capgemini.exception.ApplicationNotFoundException;
import com.capgemini.exception.CannotCheckChallanException;
import com.capgemini.exception.CannotGenerateDrivingLicenseException;
import com.capgemini.exception.CannotGenerateLearnerLicenseException;
import com.capgemini.exception.CannotUpdateApplicationException;
import com.capgemini.exception.ChallanWithVehicleNumberNotFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.InvalidLoginException;
import com.capgemini.exception.NoPendingApplicationException;
import com.capgemini.exception.NoRejectedApplicationException;
import com.capgemini.model.Applicant;
import com.capgemini.model.Application;
import com.capgemini.model.Appointment;
import com.capgemini.model.AppointmentStatus;
import com.capgemini.model.Challan;
import com.capgemini.model.RTOOfficer;
import com.capgemini.service.RTOOfficerService;

@SpringBootTest
class RTOOfficerServiceTest {
	@Autowired
	RTOOfficerService service;

	@MockBean
	private RTOOfficerDao dao;
	@MockBean
	private ApplicationDao dao1;
	@MockBean
	private DrivingLicenseDao drivingdao;
	@MockBean
	private ChallanDao challandao;

	@Test
	void testRtoOfficerWithCorrectLogin() throws InvalidLoginException, NoSuchElementException {
		RTOOfficer rto1 = new RTOOfficer("Kaviya1@gmail.com", "pass", "Kaviya");

		when(dao.save(rto1)).thenReturn(rto1);
		String str1 = service.officeLogin(rto1);
		assertEquals("ADDED TO DATABASE", str1);
	}

	@Test
	void testToCheckWithValidLogin() throws InvalidLoginException {
		RTOOfficer rto1 = new RTOOfficer("Kaviya1@gmail.com", "pass", "Kaviya");
		when(dao.findByEmail(rto1.getEmail())).thenReturn(rto1);
		// String str2= service.officeLogin(rto1);
		String str1 = service.validateRtoLogin("Kaviya1@gmail.com");
		assertEquals("VALID LOGIN", str1);
	}

	@Test
	void testToCheckChallanByVechicleNumber() throws ChallanWithVehicleNumberNotFoundException {
		Challan c = new Challan();
		c.setChallanNumber("14789");
		c.setVehicleNumber("14789");
		c.setAmount(2000.0);
		String str = c.getVehicleNumber();
		when(dao.findChallanByVehicle(str)).thenReturn(c.getChallanNumber());
		assertEquals(c.getChallanNumber(), service.checkChallanByVehicleNumber(str));
	}

	@Test
	void testGetAllPendingApplicationShouldThrowNoPendingApplicationException()
			throws IllegalArgumentException, NoPendingApplicationException {
		when(dao.findAllPendingApplication()).thenThrow(NoPendingApplicationException.class);
		assertThrows(NoPendingApplicationException.class, () -> {
			service.viewAllPendingApplications();
		});
	}

	@Test
	void testGetAllRejectedApplicationShouldThrowNoRejectedApplicationException()
			throws IllegalArgumentException, NoRejectedApplicationException {
		when(dao.findAllRejectedApplication()).thenThrow(NoRejectedApplicationException.class);
		assertThrows(NoRejectedApplicationException.class, () -> {
			service.viewAllRejectedApplications();
		});
	}

	@Test
	void testToGetTheApplicationByUsingApplicationNumber() throws ApplicationNotFoundException {
		Application a = new Application();
		a.setApplicationNumber("12345");
		when(dao.findByApplicationNumber("12345")).thenReturn(a);
		assertEquals(a, service.viewApplicationById(a.getApplicationNumber()));
	}

	@Test
	public void testModifyTestResultById() throws CannotUpdateApplicationException {
		Application application = new Application("1234", new Date(), "passed", 100, "yes", "good");
		when(dao1.existsById("1234")).thenReturn(true);
		application.setAmountPaid(500);
		Application updateApp = service.modifyTestResultById("1234", application);
		assertEquals("good", updateApp.getRemarks());
	}

	@Test
	public void checkChallanTest() throws CannotCheckChallanException {

		List<Challan> challan = service.checkAllChallan();
		when(challandao.findAllChallan()).thenReturn(challan);
		assertNotNull(challan);
	}

	@Test
	public void testEmailLicense() throws FailedToSendEmailException

	{
		assertEquals("Successfully sent email!", service.emailLicense("gayu9443@gmail.com"));
	}

	@Test
	public void testGenerateLearnerLicense() throws CannotGenerateLearnerLicenseException, ParseException {
		Application application = new Application("1234", new Date(), "passed", 100, "yes", "good");
		Applicant app = new Applicant();
		String dateString = "01/08/1985";
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		app.setDateOfBirth(formatter.parse(dateString));
		application.setApplicant(app);
		application.getApplicant().getDateOfBirth();
		when(dao.findByApplicationNumber("1234")).thenReturn(application);
		assertEquals("Learner license generated",service.generateLearnerLicense(application.getApplicationNumber()));
	}
	
	@Test
	public void testGenerateDrivingLicense() throws CannotGenerateDrivingLicenseException{
		Application application = new Application("1234", new Date(), "passed", 100, "yes", "good");
		Appointment app = new Appointment();
		app.setTestResult("passed");
		application.setAppointment(app);
		when(dao.findByApplicationNumber("1234")).thenReturn(application);
		//assertEquals("generated",service.generateDrivingLicense(application.getApplicationNumber()));
		assertNotNull(service.generateDrivingLicense(application.getApplicationNumber()));
	}

}

package com.capgemini.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capgemini.dao.UserDao;
import com.capgemini.exception.DuplicateUserFoundException;
import com.capgemini.exception.FailedToSendEmailException;
import com.capgemini.exception.ValueNotFoundException;
import com.capgemini.model.User;
import com.capgemini.service.UserService;
import com.capgemini.service.UserServiceImpl;

@SpringBootTest
public class UserServiceTest {
	
	@Autowired
	private UserService service;
	
	@MockBean
	private UserDao dao;
	
	
	@Test
	void testAddUserShouldAddUserDataToDatabase() throws DuplicateUserFoundException, FailedToSendEmailException {
		User user = new User("pranathi123@gmail.com","pranu123");
		when(dao.save(user)).thenReturn(user);
		String userToBeAdded = service.userRegistration(user);
		assertEquals(true, userToBeAdded != null);
	}
	@Test
	void testFindUserByUserLoginFromTheDatabase() throws ValueNotFoundException{
		User user = new User("pranathi123@gmail.com","pranu123");
		when(dao.findByEmail(user.getEmail())).thenReturn(user);
		User result = service.userLogin("pranathi123@gmail.com");
		assertEquals(user.getEmail(),result.getEmail());
	}
	
	@Test
	public void TestingWhetherPasswordIsUpdatedOrNot() throws ValueNotFoundException {
		User user = new User("pranathi123@gmail.com","pranu123");
        boolean result = service.changePassword(user.getEmail(),"newPassword123",user) != null;
        assertTrue(result);
		
		
	}

	@Test
	void testForgetPasswordForTheUserInTheDatabase() throws ValueNotFoundException{
		User user = new User("pranathi123@gmail.com","pranu123");
		when(dao.findByEmail("pranathi123@gmail.com")).thenReturn(user);
		String result = service.forgotPassword(user.getEmail());
		assertEquals(result,user.getPassword());
	}
}
